class animacao {
  constructor(matriz, imagem, x, variacaoY, largura, altura, larguraSprite, alturasprite) {
      this.matriz = matriz;
      this.imagem = imagem;
      this.altura = altura;
      this.x = x;
      this.variacaoY = variacaoY;
      this.y = height - this.altalt;
      this.larguraSprite = larguraSprite;
      this.alturaSprite = alturaSprite;
      
      this.frameAtual = 0;
  }
  
  exibe(){
   image(this.imagem, this.x, this.y, this.largura,this.altura, this.matriz[this.frameAtual][0], this.matriz[this.frameAtual][1], this.larguraSprite, this.alturaSprite);
   
     this.anima();
  }
}