 class inimigo extends animaçao {
  constructor(matriz, imagem, x, variacaoY, largura, altura, larguraSprite, alturaSprite, velocidade) {
   super(matriz, imagem, x, variacaoY, largura, altura, larguraSprite, alturasprite)
   
      this.velocidade = velocidade;
      this.x = width;
  }
  
  move() {
    this.x = this.x - this.velocidade;
     }
     
  aparece() {
    this.x = widt
  }
  
}