function preload() {
    imagemCenario = loadImage('imagens/cenario/floresta.png');
    imagemGameOver = loadImage('imagens/assets/game-over.png');
    imagemPersonagem = loadImage('imagens/personagem/correndo.png');
    imagemPersonagem = loadImage('imagens/inimigos/gotinha.png');
    imagemPersonagem = loadImage('imagens/inimigos/gotinha-voadora.png');
    imagemInimigoGrande = loadImage('imagens/inimigos/troll.png');
    imagemVida = loadImage('imagens/assets/coracao.png');
    imagemTelaInicial = loadImage('imagens/cenario/telainicial.png');
    fonteTelaInicial = loadFont('imagens/assets/fonteTelaInicial.otf');
    fita = loadJSON('fita/fita.json')
  
  
    somDoJogo = loadSound('sons/trilha_jogo.mp4');
    somDoPulo = loadSound('sons/somDoPulo.mp4');
}