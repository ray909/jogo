function setup() {
  createCanvas(windowWidth, windowHeigth);
  frameRate(40);
  somDoJogo.loop();
  jogo = new jogo();
  telaInicial = new TelaInicial();
  jogo.setup();
  cenaAtual = 'jogo';
  cenas = {
   jogo,
   telaInicial
  };
  botboGerenciador = new BotaoGerenciador('Iniciar', width/2, height/2);
}

function keyPressed() {
  jogo.keyPressed(key);
}

function draw() {
    cenas[cenaAtual].draw();
  }
  


